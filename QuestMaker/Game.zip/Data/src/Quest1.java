public class Quest1 extends Quest {
	
	public Quest1 (Player player, Items items) {
	super(player, items);
	}

}