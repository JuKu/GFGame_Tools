public class Player {//Abgespeckte Version der Klasse Player (f�r Quest-Entwicklung)
	
	public Player () {
	//
	}

}