public class Items {

	public int Holz = 0;
	public int Goldm�nzen = 0;
	
	public Items () {
	//
	}

}